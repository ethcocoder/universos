ParadoxOS Kernel v0.4.0
==========================

This is the production release of the ParadoxOS Kernel, a physics-native operating system.

Contents:
- bin/: Executable kernel binaries
- docs/: Implementation details and status reports

Quick Start:
  ./bin/paradox-kernel

For more info, read docs/IMPLEMENTATION_COMPLETE.md

(c) 2026 ParadoxOS Team
